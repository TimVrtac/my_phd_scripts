import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime
from pyTrigger import pyTrigger
import keyboard  
import winsound
from DAQTask import *
import os
import re
from scipy.linalg import block_diag,svd,norm
import os

#requires widgets!
from IPython.display import clear_output
from IPython.display import display
import ipywidgets as widgets


def FFT_R(fs,y):
    y = np.array(y)
    n = len(y)
    
    FFT_Y = np.fft.rfft(y,  n) / (n) * 2
    FFT_F = np.fft.rfftfreq( n, 1/fs)
    
    return FFT_F, FFT_Y

def find_impact(f):
    loc_max_f = np.argmax(f)
    print([loc_max_f])
    loc_start=np.copy(loc_max_f) 
    
    while 1: 
        if f[loc_start]>=f[loc_start-1]:
            if f[loc_start] < 1:
                break
                
        if loc_start == 0:
            break
            
        loc_start-=1
        
    loc_end_1=np.copy(loc_max_f)
    
    while f[loc_end_1]>=0.: 
        loc_end_1+=1
    
    loc_end_2=np.copy(loc_max_f)
    
    while 1:
        if f[loc_end_2]>=f[loc_end_2+1]:
            if f[loc_end_2] < 1:
                break
        if f[loc_end_2] < 1:
            break
        loc_end_2+=1
        
    
    loc_end=min([loc_end_1,loc_end_2])
    
    return loc_start,loc_end

    
def plot_data(data,impact_ok = False):

    fig = plt.figure(figsize = (22,2.5))
    if impact_ok:
        fig.patch.set_facecolor('tab:green')
        fig.patch.set_alpha(0.2)
    else:
        fig.patch.set_facecolor('tab:red')
        fig.patch.set_alpha(0.2)


    # Force close-up
    plt.subplot(141)
    
    f = data["data"][:,0]
    loc_start,loc_end = find_impact(f)
    
    plt.plot(np.linspace(0,data["time_acq"],data["sample_rate"])[:loc_end*5],data["data"][:,0][:loc_end*5])
    plt.axvspan(loc_start*(1/data["sample_rate"]), loc_end*(1/data["sample_rate"]), color='tab:blue', alpha=0.3)
    
    plt.xlabel("Time")

    # Force
    plt.subplot(142)
    plt.plot(np.linspace(0,data["time_acq"],data["sample_rate"]),data["data"][:,0])
    plt.xlabel("Time")
    
    # Time data
    plt.subplot(143)
    for p in range(int(data["data"].shape[1]-1)):
        val = np.round(np.max(np.abs(data["data"][:,1:])),2)
        plt.plot(np.linspace(0,data["time_acq"],data["sample_rate"]),data["data"][:,p+1],linewidth=0.4,alpha=0.5)
    plt.plot(np.linspace(0,data["time_acq"],data["sample_rate"]),data["data"][:,p+1],linewidth=0.4,alpha=0,label=val)
    plt.legend(loc=0)
    plt.xlabel("Time")
    
    # FFT 
    plt.subplot(144)
    freq,F = FFT_R(data["sample_rate"],data["data"][:,0])
    for p in range(int(data["data"].shape[1]-1)):
        freq,X = FFT_R(data["sample_rate"],data["data"][:,p+1])
        plt.semilogy(freq,np.abs(X/F),linewidth = 0.4)
        plt.xlim(0,20000)
    plt.xlabel("Frequency")

    plt.show()
    
def measure(task, trigger_level=1.,time_acq = 1, trigger_type='up', location='', direction='',impact_no = 0,ref_locations = None):

    '''
    This function measures data from NI MAX task
    '''
    
    sig = DAQTask(task)

        
    pt = pyTrigger(rows=int(sig.sample_rate*time_acq), channels=sig.number_of_ch,
                   trigger_type=trigger_type,
                   trigger_channel=0, 
                   trigger_level=trigger_level,
                   presamples=100)
    trig = True
    while True:
        sig.acquire()
        pt.add_data(sig.data.T)
        if pt.finished:
            break
        if pt.triggered == True and trig == True:
            winsound.Beep(1000, 50)
            trig = False
            
        if keyboard.is_pressed('q') == True:
            return None
  
    out={'created': datetime.now(),
         'ch_number':sig.number_of_ch,
         'sample_rate': int(sig.sample_rate),
         'samples': len(sig.data.T),
         'dt': 1. / sig.sample_rate,
         'channels': sig.channel_list,
         'data': pt.get_data(),
         'location': location,
         'direction': direction,
         'impact_no': impact_no,
         'ref_locations': ref_locations,
         'time_acq': time_acq}
    
    sig.clear_task(wait_until_done=False)
    
    return out

def impact_testing(daq_task,no_impacts,location,direction,ref_locations,trigger_level=10,ForceForDoubleImpact=2,NoForOverload=None,ManualRange=48,clear_plots=False,check_overload=True,check_double=True,folder_dir="./data/"):
    _data_all = []
    k = 0
    while k < no_impacts:
        if keyboard.is_pressed("esc") == True:
            break

        print("Waiting for impact %s/%s" % (k+1,no_impacts))
        winsound.Beep(500, 100)
        data = measure(daq_task,trigger_level=trigger_level, location=location, direction=direction,impact_no = int(k+1),ref_locations = ref_locations)

        if data != None:
            if clear_plots:
                clear_output()
                
            impact_ok = True
            
            if check_overload:
                if NoForOverload==None:
                    for p in range(data["data"].shape[1]-1):
                        chk = data["data"][:,p+1]
                        if np.max(np.abs(chk)) > ManualRange:
                            winsound.Beep(4000, 200)
                            print("Overload Ch %s!" % str(p+1))
                            impact_ok = False
                else:
                    for p in range(data["data"].shape[1]):
                        chk = data["data"][:,p]
                        if len(np.where(chk == np.max(chk))[0]) > NoForOverload or len(np.where(chk == np.min(chk))[0]) > NoForOverload:
                            winsound.Beep(4000, 200)
                            print("Overload Ch %s!" % str(p+1))
                            impact_ok = False

            # Simple check for double impact
            
            if check_double:
                f = data["data"][:,0]
                loc_start,loc_end = find_impact(f)

                if max(f[loc_end:]) > ForceForDoubleImpact:
                    winsound.Beep(4000, 200)
                    print("Double impact!")
                    impact_ok = False


            # Everything OK!
            if impact_ok:
                print("Impact OK!")
                _data_all.append(data)
                k += 1

            plot_data(data,impact_ok = impact_ok)


    winsound.MessageBeep()

    
    
    
    name_list = []
    for k in range(len(_data_all)):
        name_list.append("Impact " + str(k+1))

    selection = widgets.SelectMultiple(
        options=name_list,
        value=name_list,
        rows = len(name_list)
    )


    button = widgets.Button(description="Save")
    output = widgets.Output()

    display(selection, button, output)

    def on_button_clicked(B):
        with output:
            if os.path.isdir(folder_dir) != True:
                os.mkdir(folder_dir)
            lst = list(selection.value)
            good_indices = [int(value[-2:])-1 for value in lst]
            data_all = [_data_all[i] for i in good_indices]
            file_name = folder_dir +location+".npy"
            print("Saving: ", lst)
            np.save(file_name,data_all)
            print("Saved to: " + file_name)



    button.on_click(on_button_clicked) 

def FFT_R_F(fs,y):
    N = int(1)
    n = len(y)

    FFT_Y = np.fft.rfft(y, N * n) / (n) * 2
    FFT_F = np.fft.rfftfreq(N * n, 1/fs)
    return FFT_F, FFT_Y

def FFT_R_X(fs,y):
    y = np.array(y)
    N = int(1)
    n = len(y)

    FFT_Y = np.fft.rfft(y, N * n) / (n) * 2
    FFT_F = np.fft.rfftfreq(N * n, 1/fs)
    return FFT_F, FFT_Y

def cross_functions(F,X):
    S_FX = np.conj(F) * X
    S_FF = np.conj(F) * F
    S_XX = np.conj(X) * X
    S_XF = np.conj(X) * F
    return S_FX, S_FF, S_XX, S_XF

def sorted_alphanumeric(data):
    convert = lambda text: int(text) if text.isdigit() else text.lower()
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
    return sorted(data, key=alphanum_key)

def measure_operational(sig,time_acq,location,direction,ref_locations,meas_no):
    pt = pyTrigger(rows=int(sig.sample_rate*time_acq), channels=sig.number_of_ch,
                   trigger_type="up",
                   trigger_channel=0, 
                   trigger_level=100000,
                   presamples=0)




    trig = True
    while True:
        pt.triggered = True

        sig.acquire()
        pt.add_data(sig.data.T)
        if pt.finished:
            break
        if pt.triggered == True and trig == True:
            trig = False

    out={'created': datetime.now(),
         'ch_number':sig.number_of_ch,
         'sample_rate': int(sig.sample_rate),
         'samples': len(sig.data.T),
         'dt': 1. / sig.sample_rate,
         'channels': sig.channel_list,
         'data': pt.get_data(),
         'location': location,
         'direction': direction,
         'meas_no': meas_no,
         'ref_locations': ref_locations,
         'time_acq': time_acq}
    
    sig.clear_task(wait_until_done=False)
    
    return out

def log_measurements(task_name,meas_no,time_acq,location,direction,ref_locations,folder_dir = "./data/"):
    _data_all = []

    for i in range(meas_no):
        print("Press letter l to log data!")
        keyboard.wait('l')
        print("Acquisition")

        sig = DAQTask(task_name)
        data = measure_operational(sig,time_acq,location,direction,ref_locations,meas_no)

        plot_data_operational(data,meas_ok = True)

        _data_all.append(data)

    name_list = []
    for k in range(len(_data_all)):
        name_list.append("Segment " + str(k+1))

    selection = widgets.SelectMultiple(
        options=name_list,
        value=name_list,
        rows = len(name_list)
    )


    button = widgets.Button(description="Save")
    output = widgets.Output()

    display(selection, button, output)
    def on_button_clicked(B):

        with output:
            if os.path.isdir(folder_dir) != True:
                os.mkdir(folder_dir)
            lst = list(selection.value)
            good_indices = [int(value[-2:])-1 for value in lst]
            data_all = [_data_all[i] for i in good_indices]
            file_name = folder_dir+location+".npy"
            print("Saving: ", lst)
            np.save(file_name,data_all)
            print("Saved to: " + file_name)
            
    button.on_click(on_button_clicked) 

            
def plot_data_operational(data,meas_ok = False):

    fig = plt.figure(figsize = (15,3))
    if meas_ok:
        fig.patch.set_facecolor('tab:green')
        fig.patch.set_alpha(0.2)
    else:
        fig.patch.set_facecolor('tab:red')
        fig.patch.set_alpha(0.2)



    
    # Time data
    plt.subplot(121)
    for p in range(int(data["data"].shape[1])):
        plt.plot(data["data"][:,p]*1e3,linewidth = 0.4,alpha = 0.5)
    plt.xlabel("Time")
    plt.ylabel("mm/s2")
    # FFT 
    plt.subplot(122)
    for p in range(int(data["data"].shape[1])):
        freq,X = FFT_R(data["sample_rate"],data["data"][:,p])
        plt.semilogy(freq,np.abs(X)*1e3,linewidth = 0.4)
        plt.xlim(0,500)
    plt.xlabel("Frequency")
    plt.ylabel("m/s2")

    plt.show()
    
def on_button_clicked(B):
    with output:
        clear_output()
        lst_in = list(selection_in.value)
        lst_out = list(selection_out.value)
        
        fig = plt.figure(figsize =(8,6))
        plt.subplot(211)
        for select_in in lst_in:
            for select_out in lst_out:
                plt.semilogy(freq,np.abs(H_ods[:,select_out,select_in]),linewidth = 0.6)
        plt.xlim(freq[0],freq[-1])
        

        plt.subplot(413)
        for select_in in lst_in:
            for select_out in lst_out:
                plt.plot(freq,np.angle(H_ods[:,select_out,select_in]),linewidth = 0.6)
        
        plt.xlim(freq[0],freq[-1])
        plt.show()